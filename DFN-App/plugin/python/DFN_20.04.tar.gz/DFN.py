#!/usr/bin/env python
import gi
gi.require_version('Gst', '1.0')
gi.require_version('GstBase', '1.0')
gi.require_version('GstAudio', '1.0')

from gi.repository import Gst, GObject, GstBase, GstAudio, GLib
import torch

import time

import numpy as np
from df.enhance import enhance, init_df, save_audio

Gst.init(None)

DEFAULT_CHANNEL=2
FLOAT_BYTE_RATIO=4
DEFAULT_WINDOW_SIZE=32
FIXED_CAPS = Gst.Caps.from_string('audio/x-raw, format=F32LE, layout=interleaved, rate=48000, channels={ch}'.format(ch=DEFAULT_CHANNEL))

DO_MIX = False
DO_NORMALIZE = False
MIX_RATIO = 0.005
DO_COMPRESS = False

class DFN(GstBase.BaseTransform):
    __gstmetadata__ = ('DFN Python','Transform',
                      'Test Combination of DFN and Gstreamer', 'IONetwork Henry')
    

    __gsttemplates__ = (Gst.PadTemplate.new("src",
                                           Gst.PadDirection.SRC,
                                           Gst.PadPresence.ALWAYS,
                                           FIXED_CAPS),
                       Gst.PadTemplate.new("sink",
                                           Gst.PadDirection.SINK,
                                           Gst.PadPresence.ALWAYS,
                                           FIXED_CAPS))
    __gproperties__ = {
        "window-size": (int,
                 "Window Size",
                 "Number of enhance model's input chunk",
                 2,
                 GLib.MAXINT,
                 DEFAULT_WINDOW_SIZE,
                 GObject.ParamFlags.READWRITE
                )
    }
    def __init__(self):
        self.info = GstAudio.AudioInfo()
        self.model, self.df_state, _ = init_df(model_base_dir="DeepFilterNet2")
        self.window_size = DEFAULT_WINDOW_SIZE
        self.drybuf=torch.tensor([[]]*DEFAULT_CHANNEL, dtype=torch.float32)
        self.wetbuf=torch.tensor([[]]*DEFAULT_CHANNEL, dtype=torch.float32)

        self.i=0
        self.window_func = np.array([])

    def do_get_property(self, prop):
        if prop.name == 'window-size':
            return self.window_size
        
    def do_set_property(self, prop, value):
        if prop.name == 'window-size':
            self.window_size = value

    def _crossfade(self, window_func, overlap_size, sound1, sound2):
        mix_sound = np.add(
            np.multiply(sound1, window_func[:,-int(overlap_size) :]),
            np.multiply(sound2, window_func[:,0:overlap_size])
        )
        return mix_sound
    def _normalize(self):
        std = self.drybuf.std(dim=1).reshape((2,1))
        self.drybuf = (
            np.add (self.drybuf, -self.drybuf.mean(dim=1).reshape((2,1))) / (1e-3 + std)
        )
    

    def do_transform_ip(self, buf): # hanning with 64 chunks, start with all empty array
        try:
            success, info = buf.map(Gst.MapFlags.READ)
            if success == False:
                raise RuntimeError("Could not map buffer to bytes object.")

            # info.data's type is memoryview, info.size is in byte size, 
            arrlen = info.size//DEFAULT_CHANNEL//FLOAT_BYTE_RATIO
            self.window_func = np.array([np.hanning(arrlen*2)]*DEFAULT_CHANNEL)
            if self.i == 0:
                self.drybuf = torch.zeros(DEFAULT_CHANNEL, self.window_size * arrlen)
                self.wetbuf = torch.zeros(DEFAULT_CHANNEL, self.window_size * arrlen)
            
            # interleaved => order='F'
            numpy_data = np.ndarray(shape = (DEFAULT_CHANNEL, arrlen),
                                    dtype = np.float32, buffer = info.data, order='F').copy()
            self.drybuf = torch.hstack((self.drybuf, torch.from_numpy(numpy_data)))
            if DO_NORMALIZE:
                self._normalize()

            self.drybuf = self.drybuf[:, arrlen:]
            #start = time.time()
            enhanced = enhance(self.model, self.df_state, self.drybuf)
            #end = time.time()
            #print("time :", (end-start) * 10**3, "ms")

            if DO_MIX:
                enhanced = MIX_RATIO*self.drybuf + (1-MIX_RATIO)*enhanced
            
            if DO_COMPRESS:
                enhanced = 0.99 * torch.tanh(enhanced)
            
            self.wetbuf = np.hstack((
                self.wetbuf[:,arrlen:-arrlen],
                self._crossfade(self.window_func, arrlen, self.wetbuf[:,-arrlen:], enhanced[:,-2*arrlen:-arrlen]),
                enhanced[:,-arrlen:]
            ))
            buf.unmap(info)
            #buf.fill(0, self.wetbuf[:,-2*arrlen:-arrlen].tobytes())
            buf.fill(0, numpy_data.tobytes())
            #save_audio("testdir/enhanced{idx}.wav".format(idx=self.i), self.wetbuf[:,-2*arrlen:-arrlen], self.df_state.sr())
            self.i +=1
            return Gst.FlowReturn.OK
        except RuntimeError as e:
            Gst.error("Mapping error: %s" % e)
            return Gst.FlowReturn.ERROR

GObject.type_register(DFN)
__gstelementfactory__ = ("DFN", Gst.Rank.NONE, DFN)
